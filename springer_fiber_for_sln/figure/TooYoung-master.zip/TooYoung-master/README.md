# TooYoung
A small package of LaTeX to draw Young diagrams.

Put TooYoung.sty in the same folder of your document, and add \usepackage{TooYoung} in preamble. 
